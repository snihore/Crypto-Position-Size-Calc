import java.util.*;
import java.io.*;
import org.knowm.xchart.XYChart;
import org.knowm.xchart.XYChartBuilder;
import org.knowm.xchart.SwingWrapper;
import org.knowm.xchart.style.Styler;

/**
 * 
 * javac -cp ".;E:\Random\xchart-3.8.0.jar" TradeOverview.java 
 * java -cp ".;E:\Random\xchart-3.8.0.jar" TradeOverview
 */

class TradeOverview{

    public static void main(String args[]){
        List<List<Double>> data = getDataFromJournal();
        List<Double> pnlList = new ArrayList();
        List<Double> pnlList2 = new ArrayList();

        double exchangeRate = 85; // 1 dollar = 85 rupees

        int wins = 0;
        double profitAndLoss = 0;
        double profitAndLoss2 = 0;
        int total = data.size();
        double charges = 0;

        for(List<Double> list: data){
            double entry = list.get(0);
            double stoploss = list.get(1);
            double exit = list.get(2);
            double qty = list.get(3);
            double type = list.get(4);
            double result = list.get(5);

            double SLPoints = 0;
            double targetPoints = 0;
            double cont = 0.001; //BTC

            if(type == 1){
                cont = 0.001;
            }else if(type == 2){
                cont = 0.01; //ETH
            }

            if(entry > stoploss){
                SLPoints = entry - stoploss;
            }else{
                SLPoints = stoploss - entry;
            }

            if(entry > exit){
                targetPoints = entry - exit;
            }else{
                targetPoints = exit - entry;
            }
            
            double charge = 0;

            if(result == 1){
                double profit = (qty*cont)*targetPoints;
                System.out.println(profit);
                wins += 1;
                charge = calcChargesDeltaEx(Math.floor(qty), cont, entry, exit, true, true);
                charges += charge;
                profitAndLoss += profit;
                profitAndLoss2 += profit;
            
            }else{
                double loss = (qty*cont)*SLPoints;
                System.out.println(-1*loss);
                charge =  calcChargesDeltaEx(Math.floor(qty), cont, entry, stoploss, true, true);
                charges += charge;
                profitAndLoss -= loss;
                profitAndLoss2 -= loss;
                
            }

            pnlList.add(profitAndLoss);
            profitAndLoss2 -= charge;
            pnlList2.add(profitAndLoss2);

        }


        double winRate = ((double)wins/(double)total)*100;
        winRate = Math.round(winRate*100.0)/100.0;

        double profitAndLossINR = profitAndLoss2*exchangeRate;

        profitAndLoss = Math.round(profitAndLoss*100.0)/100.0;
        charges = Math.round(charges*100.0)/100.0;
        profitAndLossINR = Math.round(profitAndLossINR*100.0)/100.0;
        profitAndLoss2 = Math.round(profitAndLoss2*100.0)/100.0;

        System.out.println("Trade Overview");
        System.out.println();

        System.out.println("Total Trades: "+total);
        System.out.println("Total Winners: "+wins+", Total Lossers: "+(total-wins)+", Win Rate: "+winRate+"%");
        System.out.println("Profit&Loss: "+profitAndLoss);
        System.out.println("Total Charges: "+charges);
        System.out.println("Net Profit&Loss: "+profitAndLoss2+" ( "+profitAndLossINR+" INR).");

        // System.out.println(pnlList2);
        viewChart(pnlList, pnlList2);
        System.out.println();
        analysis(data);
        
    }

    public static List<List<Double>> getDataFromJournal() {
        List<List<Double>> dataList = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader("TradingJournal.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Split the line into at most 5 parts (ignoring anything extra at the end)
                String[] parts = line.split(", ", 7);
                
                // Parse and store numeric values in a list
                List<Double> row = new ArrayList<>();
                row.add(Double.parseDouble(parts[1])); // entry
                row.add(Double.parseDouble(parts[2])); // Stoploss
                row.add(Double.parseDouble(parts[3])); // Target
                row.add(Double.parseDouble(parts[4])); //Quantity
                row.add(handleSpecialCasesType(parts[5])); //Type BTC = 1, ETH = 2
                row.add(handleSpecialCases(parts[6])); // SL/TP/Other
                
                
                dataList.add(row);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // Display the data
        // for (List<Double> row : dataList) {
        //     System.out.println(row);
        // }

        return dataList;
    }

    public static void analysis(List<List<Double>> data){

        int longs = 0;
        int shorts = 0;
        int winLongs = 0;
        int winShorts = 0;

        List<Integer> cummulativeWinners = new ArrayList<>();
        List<Integer> cummulativelossers = new ArrayList<>();

        int temp1 = 0;
        int temp2 = 0;

        for(List<Double> list: data){
            double entry = list.get(0);
            double stoploss = list.get(1);
            double exit = list.get(2);
            double qty = list.get(3);
            double type = list.get(4);
            double result = list.get(5);

            if(entry > stoploss && entry < exit){
                longs++;
                if(result == 1){
                    winLongs++;
                }
            }else if(entry < stoploss && entry > exit){
                shorts++;
                if(result == 1){
                    winShorts++;
                }
            }

            if(result == 1){
                temp1++;
            }else{
                if(temp1 != 0 && temp1 != 1){
                    cummulativeWinners.add(temp1);
                }
                temp1 = 0;
            }
            if(result == 0){
                temp2++;
            }else{
                if(temp2 != 0 && temp2 != 1){
                    cummulativelossers.add(temp2);
                }
                temp2 = 0;
            }

        }

        if(temp1 != 0 && temp1 != 1){
            cummulativeWinners.add(temp1);
        }
        if(temp2 != 0 && temp2 != 1){
            cummulativelossers.add(temp2);
        }

        System.out.println("ANALYSIS");
        System.out.println("Total LONG trades: "+longs+", SHORT trades: "+shorts);
        System.out.println("LONG: Win >> "+winLongs+", Lose >> "+(longs-winLongs));
        System.out.println("SHORT: Win >> "+winShorts+", Lose >> "+(shorts-winShorts));
        System.out.println("Cummulative Winners: "+cummulativeWinners);
        System.out.println("Cummulative Lossers: "+cummulativelossers);

    }

    // Method to handle SL, TP, or other invalid inputs
    private static double handleSpecialCases(String input) {
        if (input.equalsIgnoreCase("SL")) {
            return 0;
        } else if (input.equalsIgnoreCase("TP")) {
            return 1;
        } else {
            System.out.println("TradingJoural Result: 404");
            return 404;
        }
    }

    private static double handleSpecialCasesType(String input) {
        if (input.equalsIgnoreCase("BTC")) {
            return 1;
        } else if (input.equalsIgnoreCase("ETH")) {
            return 2;
        } else {
            System.out.println("TradingJoural Type: 404");
            return 404;
        }
    }

    public static double calcChargesDeltaEx(double lots, double cont, double entry, double exit, boolean isMakerB, boolean isMakerS){
        /**
         * FUTURES
         * Trading Fees (Taker): 0.05%
         * Trading Fees (Maker): 0.02%
         * Settlement Fees: 0.05%
         * 18% GST is applicable on Trading Fees
         * To summarize:

Limit order stays on the book → Maker.
Limit order is matched immediately → Taker.
         */
        double tradingFeeB = 0.05;
        double tradingFeeS = 0.05;
        double GST = 0.18; //18% GST on trading fees

        if(isMakerB){
            tradingFeeB = 0.02;
        }
        if(isMakerS){
            tradingFeeS = 0.02;
        }

        //BUY Side
        double orderValueBUY = lots*cont*entry;

        double chargeBUY = (orderValueBUY*tradingFeeB)/100;
        chargeBUY = chargeBUY + chargeBUY*GST;

        //SELL Side
        double orderValueSELL = lots*cont*exit;

        double chargeSELL = (orderValueSELL*tradingFeeS)/100;
        chargeSELL = chargeSELL + chargeSELL*GST;

        // System.out.println("Total Charges(Inc. GST): "+(chargeBUY+chargeSELL));

        return chargeBUY+chargeSELL;

    }

    public static void viewChart(List<Double> pnlList, List<Double> pnlList2){

         // Create x-axis values for the number of trades (1 to n)
        List<Integer> tradeNumbers = new ArrayList<>();
        for (int i = 1; i <= pnlList.size(); i++) {
            tradeNumbers.add(i);
        }

        // Create a chart object (XYChart for line graph)
        XYChart chart = new XYChartBuilder().width(800).height(600).title("P&L vs Number of Trades")
                .xAxisTitle("Number of Trades").yAxisTitle("P&L").build();

        // Customize chart style
        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNW);
        chart.getStyler().setMarkerSize(5);
        chart.getStyler().setHasAnnotations(true);

        // Add data to chart (line chart with markers)
        // chart.addSeries("P&L", tradeNumbers, pnlList);
        chart.addSeries("P&L(Inc. Charge)", tradeNumbers, pnlList2);

        // Show the chart
        new SwingWrapper<>(chart).displayChart();

    }
}