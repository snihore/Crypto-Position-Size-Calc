import java.util.Scanner;

class PositionSizeCalc{
    public static void main(String args[]){

        double value = 61756;

        getPositionSize(value, 0.35, 0.70);

        getPositionSize(value, 0.40, 0.80);

        getPositionSize(value, 0.3, 0.6);

        getPositionSize(value, 0.35, 0.70);
        

        System.out.println();
        // calculateGannLevels();

    }

    public static void getPositionSize(double entry, double SL, double tar){
        double capital = 120;
        double rpt = 3;
        double cont = 0.001; //BTC

        // double entry = 65784.52;
        double SLPoints = (entry*SL)/100;
        double target = (entry*tar)/100;

        double rptValue = (capital*rpt)/100;
        rptValue = Math.round(rptValue* 100.0) / 100.0;

        System.out.println("RPT: $"+rptValue);

        double qty = rptValue/SLPoints;

        System.out.println("QTY: "+qty);

        double lots = qty/cont;

        System.out.println("Lots: "+lots);

        double loss = (lots*cont)*SLPoints;
        loss = Math.round(loss* 100.0) / 100.0;
        double profit = qty*target;
        profit = Math.round(profit* 100.0) / 100.0;
        System.out.println("Loss: $"+loss+", Profit: $"+profit);

        calcChargesDeltaEx(Math.floor(lots), 64057.06, entry-SLPoints, true);
        System.out.println();
    }


    public static void calcChargesDeltaEx(double lots, double entry, double exit, boolean isMaker){
        /**
         * FUTURES
         * Trading Fees (Taker): 0.05%
         * Trading Fees (Maker): 0.02%
         * Settlement Fees: 0.05%
         * 18% GST is applicable on Trading Fees
         * To summarize:

Limit order stays on the book → Maker.
Limit order is matched immediately → Taker.
         */
        double tradingFee = 0.05;
        double cont = 0.001; //BTC
        double GST = 0.18; //18% GST on trading fees

        if(isMaker){
            tradingFee = 0.02;
        }

        //BUY Side
        double orderValueBUY = lots*cont*entry;

        double chargeBUY = (orderValueBUY*tradingFee)/100;
        chargeBUY = chargeBUY + chargeBUY*GST;

        //SELL Side
        double orderValueSELL = lots*cont*exit;

        double chargeSELL = (orderValueSELL*tradingFee)/100;
        chargeSELL = chargeSELL + chargeSELL*GST;

        System.out.println("Total Charges(Inc. GST): "+(chargeBUY+chargeSELL));

    }

    public static void calculateGannLevels() {

        /**
         * Key Angles and Angular Increments:
45° → Add/Subtract 0.25
90° → Add/Subtract 0.5
135° → Add/Subtract 0.75
180° → Add/Subtract 1.0
225° → Add/Subtract 1.25
270° → Add/Subtract 1.5
315° → Add/Subtract 1.75
360° → Add/Subtract 2.0
         */
        Scanner scanner = new Scanner(System.in);

        // Input current price
        System.out.print("Enter the current price: ");
        double currentPrice = scanner.nextDouble();

        // Define angle increments for key angles
        double[] angleIncrements = {0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0}; // Corresponding to 45°, 90°, ..., 360°

        // Calculate and display upside and downside levels for each angle
        System.out.println("Upside and Downside levels based on Gann Square of 9:");
        System.out.println("Angle (Degrees) | Upside Level | Downside Level");
        System.out.println("----------------------------------------------");

        int angle = 45; // Start with 45° and increment by 45° up to 360°
        for (double increment : angleIncrements) {
            double squareRoot = Math.sqrt(currentPrice);
            double upsideLevel = Math.pow(squareRoot + increment, 2);
            double downsideLevel = Math.pow(squareRoot - increment, 2);
            System.out.printf("%-16d | %-12.2f | %-14.2f%n", angle, upsideLevel, downsideLevel);
            angle += 45; // Move to the next angle (90°, 135°, ...)
        }

        scanner.close();
    }

    
}