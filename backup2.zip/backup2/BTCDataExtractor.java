import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class BTCDataExtractor {

    static class CandleData{
        long timestamp;
        double open;
        double high;
        double low;
        double close;

        CandleData(long timestamp, double open, double high, double low, double close){
            this.timestamp = timestamp;
            this.open = open;
            this.high = high;
            this.low = low;
            this.close = close;
        }
    }

    public static void randomStrategyTest(Map<Long, List<Double>> btcDataMap) {

        List<CandleData> list = new ArrayList<>();
        double stoploss = 0.3;   // 0.30% stop loss
        double riskToReward = 2; // 2 R:R
        double rpt = 7.2;        // Risk per trade (unused, clarify purpose)

        Set<Long> set = btcDataMap.keySet();

        // Convert the set to a list and sort it
        List<Long> sortedList = new ArrayList<>(set);
        Collections.sort(sortedList);

        // Prepare the formatter for timestamp
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        // Convert btcDataMap to list of CandleData
        for (long key : sortedList) {
            CandleData data = new CandleData(
                    key,
                    btcDataMap.get(key).get(0),
                    btcDataMap.get(key).get(1),
                    btcDataMap.get(key).get(2),
                    btcDataMap.get(key).get(3)
            );
            list.add(data);
        }

        // Start testing strategy
        int tradeCount = 0;
        int winners = 0;
        int losers = 0;

        for (int i = 0; i < list.size(); i++) {
            CandleData enterCandle = list.get(i);
            double enterPrice = enterCandle.close; // Short entry at candle close

            // Calculate stop loss (above entry price) and target (below entry price)
            double slPoints = (enterPrice * stoploss) / 100;
            double exitSL = enterPrice + slPoints; // Stop loss for short trade
            double exitTarget = enterPrice - (slPoints * riskToReward); // Target for short trade

            System.out.println("New Short Trade: Entry Price = " + enterPrice + ", Stop Loss = " + exitSL + ", Target = " + exitTarget);

            boolean tradeClosed = false;

            // Loop over the next candles to find where the stop loss or target is hit
            for (int j = i + 1; j < list.size(); j++) {
                CandleData currentCandle = list.get(j);
                double high = currentCandle.high;
                double low = currentCandle.low;
                double close = currentCandle.close;

                // Check if Stop Loss is hit (price goes higher than SL)
                if (high > exitSL) {
                    System.out.println("SL Hit: Entry = " + enterPrice + ", Exit = " + exitSL + ", High = " + high + ", Close = " + close);
                    tradeClosed = true;
                    losers++; // Increment losers count
                }
                // Check if Target is hit (price goes lower than target)
                else if (low < exitTarget) {
                    System.out.println("Target Hit: Entry = " + enterPrice + ", Exit = " + exitTarget + ", Low = " + low + ", Close = " + close);
                    tradeClosed = true;
                    winners++; // Increment winners count
                }

                if (tradeClosed) {
                    tradeCount++;
                    String readableOpenTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(enterCandle.timestamp), ZoneId.systemDefault()).format(formatter);
                    String readableExitTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(currentCandle.timestamp), ZoneId.systemDefault()).format(formatter);
                    
                    System.out.println("Trade " + tradeCount + " closed! Entered on: " + readableOpenTime + " Exited on: " + readableExitTime + "\n");
                    
                    // Move `i` to `j - 1` to skip to the next candle after the trade closes
                    i = j - 1; 
                    break;
                }
            }
        }

        // Print total winners, losers, and win rate
        System.out.println("Total Trades: " + tradeCount);
        System.out.println("Total Winners: " + winners);
        System.out.println("Total Losers: " + losers);
        
        double winRate = tradeCount > 0 ? ((double) winners / tradeCount) * 100 : 0;
        System.out.println("Win Rate: " + winRate + "%");
    }
 
    public static void main(String[] args) {
        String filePath = "BTCData.json"; // Path to your JSON file
        Map<Long, List<Double>> btcDataMap = new HashMap<>();

        // Formatter to display date and time in a readable format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            StringBuilder dataBuilder = new StringBuilder();
            String line;

            // Read the entire JSON file into a StringBuilder
            while ((line = reader.readLine()) != null) {
                dataBuilder.append(line);
            }

            // Get the raw data from the file
            String rawData = dataBuilder.toString();

            // Clean up the string to ensure no unnecessary brackets and trim spaces
            rawData = rawData.replace("[[", "").replace("]]", "");

            // Now split the data based on `],\n[` to separate each candlestick entry
            String[] candles = rawData.split("\\],\\s*\\[");

            // Iterate over each candle (which is now a string)
            for (int i = 1; i < candles.length-1; i++) {
                String candle = candles[i];

                // Now split individual candle data based on commas
                String[] fields = candle.split(",");

                // Extract the required values and convert the timestamp
                List<Double> extractedValues = new ArrayList<>();

                // Convert open time and close time from Unix timestamp to human-readable format
                long openTime = Long.parseLong(fields[0].trim());
                long closeTime = Long.parseLong(fields[6].trim());

                // Convert to LocalDateTime and format
                String readableOpenTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(openTime), ZoneId.systemDefault()).format(formatter);
                String readableCloseTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(closeTime), ZoneId.systemDefault()).format(formatter);

                // Add formatted times to the list
                // extractedValues.add(readableOpenTime); // Open time (formatted)
                extractedValues.add(Double.valueOf(fields[1].replace("\"", "").trim())); // Open price
                extractedValues.add(Double.valueOf(fields[2].replace("\"", "").trim())); // High price
                extractedValues.add(Double.valueOf(fields[3].replace("\"", "").trim())); // Low price
                extractedValues.add(Double.valueOf(fields[4].replace("\"", "").trim())); // Close price
                // extractedValues.add(readableCloseTime); // Close time (formatted)

                // Add this list to the map with the index as the key
                btcDataMap.put(openTime, extractedValues);
            }

            //Sort
            Set<Long> entries = btcDataMap.keySet();
            

            // Print the extracted data to verify
            System.out.println("Total Items: "+btcDataMap.size());
            // for (String entry : entries) {
            //     System.out.println("Index: " + entry + ", Values: " + btcDataMap.get(entry));
            // }

            randomStrategyTest(btcDataMap);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
