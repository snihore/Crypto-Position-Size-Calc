import java.util.*;
import org.knowm.xchart.XYChart;
import org.knowm.xchart.XYChartBuilder;
import org.knowm.xchart.SwingWrapper;
import org.knowm.xchart.style.Styler;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * javac -cp ".;E:\Random\xchart-3.8.0.jar" TradePLGraph.java 
 * java -cp ".;E:\Random\xchart-3.8.0.jar" TradePLGraph
 */

public class TradePLGraph {

    public static void main(String[] args) {
        // Sample P&L data for trades
        Map<String, List> resultMap = getPLOutput();
        List<Double> pnlList = resultMap.get("PL");
        List<Double> pnlList2 = resultMap.get("PLCharge");
        List<Double> capitals = resultMap.get("Capitals");
        List<Double> tradePL = resultMap.get("TradePL");
        List<Double> pnlList3 = resultMap.get("PLExp");
        // pnlList.add(500.0);
        // pnlList.add(-200.0);
        // pnlList.add(300.0);
        // pnlList.add(100.0);
        // pnlList.add(-50.0);
        // pnlList.add(400.0);
        
        // Create x-axis values for the number of trades (1 to n)
        List<Integer> tradeNumbers = new ArrayList<>();
        for (int i = 1; i <= pnlList.size(); i++) {
            tradeNumbers.add(i);
        }

        // Create a chart object (XYChart for line graph)
        XYChart chart = new XYChartBuilder().width(800).height(600).title("P&L vs Number of Trades")
                .xAxisTitle("Number of Trades").yAxisTitle("P&L").build();

        // Customize chart style
        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNW);
        chart.getStyler().setMarkerSize(5);
        chart.getStyler().setHasAnnotations(true);

        // Add data to chart (line chart with markers)
        chart.addSeries("P&L", tradeNumbers, pnlList);
        chart.addSeries("P&LCharge", tradeNumbers, pnlList2);
        chart.addSeries("P&LExp", tradeNumbers, pnlList3);
        // chart.addSeries("Capitals", tradeNumbers, capitals);
        // chart.addSeries("Trade P&L", tradeNumbers, tradePL);

        // Show the chart
        new SwingWrapper<>(chart).displayChart();
    }

    public static Map<String, List> getPLOutput(){
        Scanner in = new Scanner(System.in);
        System.out.println("Hello Random");

        Random rand = new Random();

        Map<String, List> resultMap= new HashMap<>();
        List<Double> result = new ArrayList<>();
        List<Double> result2 = new ArrayList<>();
        List<Double> result3 = new ArrayList<>();
        List<Double> tradePL = new ArrayList<>();

        Map<Integer, List> entryMap = new HashMap();

        // System.out.println("Enter Capital: ");
        double entry = 63858.48; // BTC/ETH
        double cont = 0.001; //BTC

        double capital = 120;//in.nextDouble();
        double capital2 = new Double(capital);
        double capital3 = new Double(capital);
        double minCap = 0;
        double maxCap = 0;
        double margin = 20;
        // System.out.println("Enter RPT(%): ");
        double rpt = 3;//in.nextDouble();
        // System.out.println("Enter Number of Trades: ");
        int numOfTrades = 300;//in.nextInt();
        int executed = 0;
        // System.out.println("Enter Risk to Reward Ratio: ");
        double RR = 2;//in.nextDouble();

        double rptV = (capital*rpt)/100;
        rptV = Math.round(rptV* 100.0) / 100.0;

        // System.out.println("Risk Per trade: "+rptV);

        //Profit And Loss Variable
        double profitAndLoss = 0;
        double profitAndLoss2 = 0;
        double profitAndLoss3 = 0;
        int winners = 0;
        int lossers = 0;


        System.out.println();
        System.out.println("Capital: "+capital+", Risk Per Trade: "+rptV+", No. of Trades: "+numOfTrades+", Risk to Reward: "+RR);
        
        List<Double> capitals = new ArrayList();

        for(int i=0; i<numOfTrades; i++){

            //Random entry price

            //Random stoploss percentage
            double SL = 0.30 + (0.35 - 0.30) * rand.nextDouble();//0.15 to 0.7
            SL = Math.round(SL * 100.0) / 100.0;
            // System.out.println(SL);
            

            List<Double> list = new ArrayList();
            list.add(SL);
            list.add(SL*RR);

            entryMap.put(i, list);
        }

        // System.out.println(entryMap.keySet());
        // System.out.println("Entry Map: "+entryMap.size());

        for(int i: entryMap.keySet()){
            
            
            List list = entryMap.get(i);
            double SL = (double)list.get(0);
            double target = (double)list.get(1);

            double entry2 = (entry*margin)/100;
            entry2 = Math.round(entry2 * 100.0) / 100.0;

            double SLPoints = (entry*SL)/100;
            SLPoints = Math.round(SLPoints * 100.0) / 100.0;
            double targetPoints = (entry*target)/100;
            targetPoints = Math.round(targetPoints * 100.0) / 100.0;

            executed++;

            ///////////
            // System.out.println("Capital3: "+capital3);
            double rptV3 = (capital3*rpt)/100;
            rptV3 = Math.round(rptV3* 100.0) / 100.0;

            // int qty = (int)Math.round(rptV/SLPoints);
            double qty = rptV/SLPoints;
            double qty3 = rptV3/SLPoints;

            //Calculate Lots
            double lots = qty/cont;
            double lots3 = qty3/cont;

            //Random result flag, 0 - loss, 1 - profit
            int flag = randDecision();//rand.nextInt(2);//rand.nextInt(100000)%2; //randDecision();

            double charge = 0;
            double charge3 = 0;
            //Calculate P&L based on Random Flag

            if(flag == 0){
                lossers++;
                double loss = qty*SLPoints;
                double loss3 = qty3*SLPoints;
                tradePL.add(loss);
                profitAndLoss -= loss;
                profitAndLoss2 -= loss;
                profitAndLoss3 -= loss3;
                //Calculate Charges
                charge = calcChargesDeltaEx(Math.floor(lots), entry, entry-SLPoints, true);
                charge3 = calcChargesDeltaEx(Math.floor(lots3), entry, entry-SLPoints, true);
                // System.out.println("Capital: "+capital3+", LOSS >>> -"+(loss3+charge3));
                capital3 -= loss3;
            }else if(flag == 1){
                winners++;
                double profit = qty*targetPoints;
                double profit3 = qty3*targetPoints;
                tradePL.add(profit);
                profitAndLoss += profit;
                profitAndLoss2 += profit;
                profitAndLoss3 += profit3;
                //Calculate Charges
                charge = calcChargesDeltaEx(Math.floor(lots), entry, entry+targetPoints, true);
                charge3 = calcChargesDeltaEx(Math.floor(lots3), entry, entry+targetPoints, true);
                // System.out.println("Capital: "+capital3+", PROFIT >>> "+(profit3-charge3));
                capital3 += profit3;
            }else{
                System.out.println("Try Again !");
                // continue;
                return resultMap;
            }

            charge = Math.round(charge * 100.0) / 100.0;
            charge3 = Math.round(charge3 * 100.0) / 100.0;

            profitAndLoss = Math.round(profitAndLoss * 100.0) / 100.0;
            result.add(profitAndLoss);
            profitAndLoss2 -= charge;
            profitAndLoss2 = Math.round(profitAndLoss2 * 100.0) / 100.0;
            result2.add(profitAndLoss2);
            ////////////////
            capital3 -= charge3;
            profitAndLoss3 -= charge3;
            profitAndLoss3 = Math.round(profitAndLoss3 * 100.0) / 100.0;
            result3.add(profitAndLoss3);

            double temp = capital + profitAndLoss2;
            capitals.add(temp);

            if(minCap  == 0){
                minCap = temp;
            }else if(minCap > temp){
                minCap = temp;
            }
            
            if(maxCap  == 0){
                maxCap = temp;
            }else if(maxCap < temp){
                maxCap = temp;
            }
            // System.out.println("Entry: "+entry+", SL: "+SLPoints+", target: "+targetPoints+", Quantity: "+qty+", Result: "+flag+", P&L: "+profitAndLoss);
     
        }

        double ROI = (profitAndLoss/capital)*100;
        ROI = Math.round(ROI*100.0)/100.0;
        double ROI2 = (profitAndLoss2/capital2)*100;
        ROI2 = Math.round(ROI2*100.0)/100.0;
        double ROI3 = (profitAndLoss3/capital)*100;
        ROI3 = Math.round(ROI3*100.0)/100.0;

        capital = capital + profitAndLoss;
        capital2 = capital2 + profitAndLoss2;
        capital = Math.round(capital*100.0)/100.0;
        capital2 = Math.round(capital2*100.0)/100.0;
        capital3 = Math.round(capital3*100.0)/100.0;

        double winRate = ((double)winners/(double)executed)*100;
        winRate = Math.round(winRate*100.0)/100.0;

        minCap = Math.round(minCap*100.0)/100.0;
        maxCap = Math.round(maxCap*100.0)/100.0;


        //Show Result
        System.out.println();
        System.out.println("################ RESULT #################");
        System.out.println();
        System.out.println("No. of Trades Executed: "+executed+", P&L: "+profitAndLoss+", P&L with charge: "+profitAndLoss2+", P&L Exp: "+profitAndLoss3);
        System.out.println("Total Winners: "+winners+", Total Lossers: "+lossers+", Win Rate: "+winRate+"%");
        System.out.println();
        System.out.println("Capital: "+capital+"("+ROI+"%)");
        System.out.println("Capital(Inc. Charges): "+capital2+"("+ROI2+"%)");
        System.out.println("Capital(Exp): "+capital3+"("+ROI3+"%)");
        System.out.println("Lowest Capital Reached: "+minCap);
        System.out.println("Highest Capital Reached: "+maxCap);
        if(profitAndLoss2 > 0){
            System.out.println("PROFITABLE");
        }else{
            System.out.println("LOSSER");
        }

        // System.out.println(capitals);

        resultMap.put("PL", result);
        resultMap.put("PLCharge", result2);
        resultMap.put("PLExp", result3);
        resultMap.put("Capitals", capitals);
        resultMap.put("TradePL", tradePL);

        return resultMap;
    }
    public static int randDecision(){
        // int value1 = 214;
        // int value2 = 786;

        // // Create an instance of Random class
        // Random random = new Random();

        // // Generate a random value that is either 214 or 786
        // int randomValue = random.nextBoolean() ? value1 : value2;

        // if(randomValue == 214)
        //     return 1;
        // else
        //     return 0;
        Random random = new Random();

        // int value = random.nextInt(100);

        // if(value > 50){
        //     return 1;
        // }else{
        //     return 0;
        // }
        boolean value = random.nextBoolean();
        
        if(value){
            return 1;
        }
        return 0;
    }

    public static double calcChargesDeltaEx(double lots, double entry, double exit, boolean isMaker){
        /**
         * FUTURES
         * Trading Fees (Taker): 0.05%
         * Trading Fees (Maker): 0.02%
         * Settlement Fees: 0.05%
         * 18% GST is applicable on Trading Fees
         * To summarize:

Limit order stays on the book → Maker.
Limit order is matched immediately → Taker.
         */
        double tradingFee = 0.05;
        double cont = 0.001; //BTC
        double GST = 0.18; //18% GST on trading fees

        if(isMaker){
            tradingFee = 0.02;
        }

        //BUY Side
        double orderValueBUY = lots*cont*entry;

        double chargeBUY = (orderValueBUY*tradingFee)/100;
        chargeBUY = chargeBUY + chargeBUY*GST;

        //SELL Side
        double orderValueSELL = lots*cont*exit;

        double chargeSELL = (orderValueSELL*tradingFee)/100;
        chargeSELL = chargeSELL + chargeSELL*GST;

        // System.out.println("Total Charges(Inc. GST): "+(chargeBUY+chargeSELL));

        return chargeBUY+chargeSELL;

    }
}
