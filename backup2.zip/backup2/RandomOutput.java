import java.util.*;
import java.io.*;

/***
 * Predicting future price of any asset/stock is RANDOM but,
 * it is less random because of some initial conditions. We don't know the outcome but at certain point of time,
 * after series of events we have found some patterns. Process is random but outcome is not - 
 * it depends on initial conditions and series of events.
 * 
 * Initial Condition + Randomness = PATTERN
 * 
 * Initial Conditions:
 * 1. Risk Per Trade(RPT) --> Capital
 * 2. Risk to Reward Ratio(RR) --> SL
 * 3. Number of Trades(N)
 * 4. random flag/flip a coin
 * 5. Stoploss is also an initial condition but it depends on market condition. Keep minimum SL.
 * 6. Entry price/Asset price is not an initial condition.
 * 7. Calculated Quantity - it depends on asset price and asset type.
 *      (Profit and Loss depends on Quantity, calculate and use ACCURATE QUANTITY)
 *
 * Profitability = Win Rate + 1st Initial Conditions 
 * Win Rate = Trade's Initial Condition 
 *
 */

class RandomOutput{

    public static final double cont = 0.001; //BTC

    public static void main(String agrs[]){
        System.out.println("Hello Random");

        //Get data from Trading Journal
        List<List<Double>> list = new ArrayList<>();

        randomOutput(46, null); // Enter value from 0 to 100 %
    }

    public static void randomOutput(double expectedWinRate, List<List<Double>> trades){
        Scanner in = new Scanner(System.in);

        Random rand = new Random();

        Map<Integer, List> entryMap = new HashMap();

        // System.out.println("Enter Capital: ");
        double entryDefault = 63858.48; // BTC/ETH

        double capital = 120;//in.nextDouble();
        double capital2 = new Double(capital);
        double minCap = 0;
        double maxCap = 0;
        
        double[] laverage = {0, 0};
        double[] charges = {0, 0};

        // System.out.println("Enter RPT(%): ");
        double rpt = 3;//in.nextDouble();
        // System.out.println("Enter Number of Trades: ");

        
        int numOfTrades = 0;//in.nextInt();
        if(trades == null || trades.size() == 0){
            numOfTrades = 65;
        }else{
            numOfTrades = trades.size();
        }

        int executed = 0;
        // System.out.println("Enter Risk to Reward Ratio: ");
        double RR = 2;//in.nextDouble();

        double rptV = (capital*rpt)/100;
        rptV = Math.round(rptV* 100.0) / 100.0;

        // System.out.println("Risk Per trade: "+rptV);

        //Profit And Loss Variable
        double profitAndLoss = 0;
        double profitAndLoss2 = 0;
        int winners = 0;
        int lossers = 0;

        List<Double> capitals = new ArrayList();

        for(int i=0; i<numOfTrades; i++){
            if(trades == null || trades.size() == 0){
                //Random entry price

                //Random stoploss percentage
                double SL = 0.30 + (0.30 - 0.30) * rand.nextDouble();//0.15 to 0.7
                SL = Math.round(SL * 100.0) / 100.0;
                // System.out.println(SL);
                

                List<Double> list = new ArrayList();
                list.add(SL);
                list.add(SL*RR);

                entryMap.put(i, list);
            }else{
                List<Double> list = new ArrayList<>();
                list.add(trades.get(i).get(1));
                list.add(trades.get(i).get(2));

                //Assuming each trade entry price in unique and Integer
                entryMap.put(i, list);
            }
        }

        // System.out.println(entryMap.keySet());
        // System.out.println("Entry Map: "+entryMap.size());

        for(int i: entryMap.keySet()){
            
            List list = entryMap.get(i);
            double SL = (double)list.get(0);
            double target = (double)list.get(1);
            double entry = 0.0;

            if(trades == null || trades.size() == 0){
                entry = entryDefault;
            }else{
                entry = trades.get(i).get(0);
            }

            // double entry2 = (entry*margin)/100;
            // entry2 = Math.round(entry2 * 100.0) / 100.0;

            double SLPoints = (entry*SL)/100;
            SLPoints = Math.round(SLPoints * 100.0) / 100.0;
            double targetPoints = (entry*target)/100;
            targetPoints = Math.round(targetPoints * 100.0) / 100.0;

            executed++;

            // int qty = (int)Math.round(rptV/SLPoints);
            double qty = rptV/SLPoints;

            //Calculate Lots
            double lots = qty/cont;
            double lotsFloor = Math.floor(lots);
            // System.out.println("Lots: "+lotsFloor+", "+lots);

            //Calculate Laverage Required
            double capRequired = (lotsFloor*cont)*entry;

            double tempLav = capRequired/capital;
            tempLav = Math.round(tempLav * 100.0) / 100.0;

            if(laverage[0] == 0){
                laverage[0] = tempLav;
            }else if(laverage[0] > tempLav){
                laverage[0] = tempLav;
            }

            if(laverage[1] == 0){
                laverage[1] = tempLav;
            }else if(laverage[1] < tempLav){
                laverage[1] = tempLav;
            }

            //Random result flag, 0 - loss, 1 - profit
            int flag = randDecision();//rand.nextInt(2);//rand.nextInt(100000)%2; //randDecision();

            double charge = 0;
            //Calculate P&L based on Random Flag

            if(flag == 0){
                lossers++;
                double loss = (lotsFloor*cont)*SLPoints;
                // System.out.println("LOSS >>> -"+loss);
                profitAndLoss -= loss;
                profitAndLoss2 -= loss;
                //Calculate Charges
                charge = calcChargesDeltaEx(lotsFloor, entry, entry-SLPoints, true);
            }else if(flag == 1){
                winners++;
                double profit = (lotsFloor*cont)*targetPoints;
                // System.out.println("PROFIT >>> "+profit);
                profitAndLoss += profit;
                profitAndLoss2 += profit;
                //Calculate Charges
                charge = calcChargesDeltaEx(lotsFloor, entry, entry+targetPoints, true);
            }else{
                System.out.println("Try Again !");
                continue;
            }

            charge = Math.round(charge * 100.0) / 100.0;

            if(charges[0] == 0){
                charges[0] = charge;
            }else if(charges[0] > charge){
                charges[0] = charge;
            }

            if(charges[1] == 0){
                charges[1] = charge;
            }else if(charges[1] < charge){
                charges[1] = charge;
            }

            profitAndLoss = Math.round(profitAndLoss * 100.0) / 100.0;
            profitAndLoss2 -= charge;
            profitAndLoss2 = Math.round(profitAndLoss2 * 100.0) / 100.0;

            double temp = capital + profitAndLoss2;
            capitals.add(temp);

            if(minCap  == 0){
                minCap = temp;
            }else if(minCap > temp){
                minCap = temp;
            }
            
            if(maxCap  == 0){
                maxCap = temp;
            }else if(maxCap < temp){
                maxCap = temp;
            }
            // System.out.println("Entry: "+entry+", SL: "+SLPoints+", target: "+targetPoints+", Quantity: "+qty+", Result: "+flag+", P&L: "+profitAndLoss);
     
        }


        double winRate = ((double)winners/(double)executed)*100;
        winRate = Math.round(winRate*100.0)/100.0;

        if(Math.floor(expectedWinRate) == 0 || Math.floor(new Double(winRate)) == Math.floor(expectedWinRate)){
            System.out.println();
            System.out.println("Capital: "+capital+", Risk Per Trade: "+rptV+", No. of Trades: "+numOfTrades+", Risk to Reward: "+RR);
        
        }

        double ROI = (profitAndLoss/capital)*100;
        ROI = Math.round(ROI*100.0)/100.0;
        double ROI2 = (profitAndLoss2/capital2)*100;
        ROI2 = Math.round(ROI2*100.0)/100.0;

        capital = capital + profitAndLoss;
        capital2 = capital2 + profitAndLoss2;
        capital = Math.round(capital*100.0)/100.0;
        capital2 = Math.round(capital2*100.0)/100.0;

        minCap = Math.round(minCap*100.0)/100.0;
        maxCap = Math.round(maxCap*100.0)/100.0;

        if(Math.floor(expectedWinRate) != 0 && Math.floor(new Double(winRate)) != Math.floor(expectedWinRate)){
            randomOutput(expectedWinRate, trades);
        }else{
            //Show Result
            System.out.println();
            System.out.println("################ RESULT #################");
            System.out.println();
            System.out.println("No. of Trades Executed: "+executed+", P&L: "+profitAndLoss+", P&L with charge: "+profitAndLoss2);
            System.out.println("Total Winners: "+winners+", Total Lossers: "+lossers+", Win Rate: "+winRate+"%");
            System.out.println();
            System.out.println("Capital: "+capital+"("+ROI+"%)");
            System.out.println("Capital(Inc. Charges): "+capital2+"("+ROI2+"%)");
            System.out.println("Lowest Capital Reached: "+minCap);
            System.out.println("Highest Capital Reached: "+maxCap);
            System.out.println("Laverage -> Min: "+laverage[0]+", Max: "+laverage[1]);
            System.out.println("Charges -> Min: "+charges[0]+", Max: "+charges[1]);
            if(profitAndLoss2 > 0){
                System.out.println("PROFITABLE");
            }else{
                System.out.println("LOSSER");
            }

            // System.out.println(capitals);
        }
        

    }

    public static int randDecision(){
        // int value1 = 214;
        // int value2 = 786;

        // // Create an instance of Random class
        // Random random = new Random();

        // // Generate a random value that is either 214 or 786
        // int randomValue = random.nextBoolean() ? value1 : value2;

        // if(randomValue == 214)
        //     return 1;
        // else
        //     return 0;

        Random random = new Random();

        // int value = random.nextInt(100);

        // if(value > 50){
        //     return 1;
        // }else{
        //     return 0;
        // }
        boolean value = random.nextBoolean();
        
        if(value){
            return 1;
        }
        return 0;
    }

    public static double calcChargesDeltaEx(double lots, double entry, double exit, boolean isMaker){
        /**
         * FUTURES
         * Trading Fees (Taker): 0.05%
         * Trading Fees (Maker): 0.02%
         * Settlement Fees: 0.05%
         * 18% GST is applicable on Trading Fees
         * To summarize:

Limit order stays on the book → Maker.
Limit order is matched immediately → Taker.
         */
        double tradingFee = 0.05;
        double GST = 0.18; //18% GST on trading fees

        if(isMaker){
            tradingFee = 0.02;
        }

        //BUY Side
        double orderValueBUY = lots*cont*entry;

        double chargeBUY = (orderValueBUY*tradingFee)/100;
        chargeBUY = chargeBUY + chargeBUY*GST;

        //SELL Side
        double orderValueSELL = lots*cont*exit;

        double chargeSELL = (orderValueSELL*tradingFee)/100;
        chargeSELL = chargeSELL + chargeSELL*GST;

        // System.out.println("Total Charges(Inc. GST): "+(chargeBUY+chargeSELL));

        return chargeBUY+chargeSELL;

    }

}